package hashCode;

import java.util.ArrayList;

public abstract class EenDataStructuur {

    public int[] books;
    public ArrayList<Library> libraries;
    public int amountDaysForScanning;
    public int maxBoeken;

    @Override
    public String toString() {
        //todo implementeer dit (Arthur)
        return "TODO";
    }

}

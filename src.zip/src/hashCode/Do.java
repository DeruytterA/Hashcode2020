package hashCode;

public interface Do {
    public void doYourThing();
}

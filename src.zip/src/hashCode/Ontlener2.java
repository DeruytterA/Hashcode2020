package hashCode;

public class Ontlener2 {
}
